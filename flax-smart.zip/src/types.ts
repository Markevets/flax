export interface Device {
  id: string;
  name: string;
  type: 'laptop' | 'proyector' | 'ventilador' | 'luces' | 'aire_acondicionado' | 'smartboard' | 'bocinas';
  description: string;
  isOn: boolean;
  temperature: number;
  batteryLevel: number | null;
  powerConsumption: number;
  basePower: number;
  canHeat: boolean;
}

export interface Classroom {
  id: string;
  name: string;
  building: string;
  devices: Device[];
}

export interface User {
  username: string;
  name: string;
  role: 'Docente' | 'Administrador' | 'Mantenimiento' | 'Invitado';
  avatar: string;
  email: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  classroom: string;
  device: string;
  type: 'info' | 'success' | 'warning' | 'danger';
}
