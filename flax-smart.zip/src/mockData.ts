import { Classroom } from './types';

export const INITIAL_CLASSROOMS: Classroom[] = [
  {
    id: 'aula_101',
    name: 'Aula 101 - Laboratorio de Ciencias',
    building: 'Pabellón A - Primer Piso',
    devices: [
      {
        id: '101_laptop_docente',
        name: 'Laptop de Docente (Lenovo)',
        type: 'laptop',
        description: 'Laptop principal conectada a la estación del profesor y sistema multimedia.',
        isOn: true,
        temperature: 38,
        batteryLevel: 85,
        powerConsumption: 45,
        basePower: 45,
        canHeat: true
      },
      {
        id: '101_proyector_epson',
        name: 'Proyector Epson Ultra-HD',
        type: 'proyector',
        description: 'Proyector del techo principal para proyección de diapositivas y guías de laboratorio.',
        isOn: true,
        temperature: 55,
        batteryLevel: null,
        powerConsumption: 280,
        basePower: 280,
        canHeat: true
      },
      {
        id: '101_ventilador_norte',
        name: 'Ventilador de Techo (Norte)',
        type: 'ventilador',
        description: 'Ventilador de velocidad variable para regular la circulación del aire en zona norte.',
        isOn: false,
        temperature: 24,
        batteryLevel: null,
        powerConsumption: 0.5,
        basePower: 65,
        canHeat: false
      },
      {
        id: '101_ventilador_sur',
        name: 'Ventilador de Techo (Sur)',
        type: 'ventilador',
        description: 'Ventilador de velocidad variable para regular la circulación del aire en zona sur.',
        isOn: true,
        temperature: 28,
        batteryLevel: null,
        powerConsumption: 65,
        basePower: 65,
        canHeat: false
      },
      {
        id: '101_aire_acondicionado',
        name: 'Aire Acondicionado Split',
        type: 'aire_acondicionado',
        description: 'Termostato y enfriador central del laboratorio de ciencias.',
        isOn: false,
        temperature: 22,
        batteryLevel: null,
        powerConsumption: 1.2,
        basePower: 1200,
        canHeat: false
      },
      {
        id: '101_luces_led',
        name: 'Sistema de Luces LED',
        type: 'luces',
        description: 'Conjunto de luminarias LED de bajo consumo con control de intensidad dactilar.',
        isOn: true,
        temperature: 29,
        batteryLevel: null,
        powerConsumption: 120,
        basePower: 120,
        canHeat: false
      }
    ]
  },
  {
    id: 'aula_102',
    name: 'Aula 102 - Aula de Multimedia',
    building: 'Pabellón A - Primer Piso',
    devices: [
      {
        id: '102_smartboard_lg',
        name: 'Pizarra Inteligente LG 86"',
        type: 'smartboard',
        description: 'Pantalla táctil interactiva multipunto para explicaciones digitales.',
        isOn: true,
        temperature: 42,
        batteryLevel: null,
        powerConsumption: 340,
        basePower: 340,
        canHeat: true
      },
      {
        id: '102_laptop_estudiante_1',
        name: 'Laptop Estudiante Chromebook',
        type: 'laptop',
        description: 'Dispositivo portátil de préstamo estudiantil para tareas de investigación.',
        isOn: false,
        temperature: 22,
        batteryLevel: 15,
        powerConsumption: 0.2,
        basePower: 30,
        canHeat: true
      },
      {
        id: '102_proyector_optoma',
        name: 'Proyector Optoma 4K',
        type: 'proyector',
        description: 'Proyector auxiliar de tiro corto para el fondo del aula.',
        isOn: false,
        temperature: 25,
        batteryLevel: null,
        powerConsumption: 0.8,
        basePower: 260,
        canHeat: true
      },
      {
        id: '102_bocinas_surround',
        name: 'Sistema de Sonido JBL 5.1',
        type: 'bocinas',
        description: 'Bocinas de sonido envolvente para material audiovisual e interactivo.',
        isOn: true,
        temperature: 28,
        batteryLevel: null,
        powerConsumption: 80,
        basePower: 80,
        canHeat: false
      },
      {
        id: '102_luces_multimedia',
        name: 'Luces LED Panelable',
        type: 'luces',
        description: 'Paneles de luces atenuables para mejorar la visibilidad del proyector.',
        isOn: false,
        temperature: 21,
        batteryLevel: null,
        powerConsumption: 0.1,
        basePower: 150,
        canHeat: false
      }
    ]
  },
  {
    id: 'aula_203',
    name: 'Aula 203 - Taller de Robótica',
    building: 'Pabellón B - Segundo Piso',
    devices: [
      {
        id: '203_smartboard_promethean',
        name: 'Panel Interactivo Promethean v7',
        type: 'smartboard',
        description: 'Centro interactivo para revisión de esquemáticos y diseño de circuitos.',
        isOn: true,
        temperature: 46,
        batteryLevel: null,
        powerConsumption: 390,
        basePower: 390,
        canHeat: true
      },
      {
        id: '203_laptop_docente',
        name: 'Laptop Workstation Docente',
        type: 'laptop',
        description: 'Laptop de alta capacidad con software CAD y simulación de circuitos.',
        isOn: true,
        temperature: 49,
        batteryLevel: 98,
        powerConsumption: 95,
        basePower: 95,
        canHeat: true
      },
      {
        id: '203_ventilador_industrial',
        name: 'Ventilador Industrial Pared',
        type: 'ventilador',
        description: 'Ventilador de alta potencia para disipar humos de soldadura y calor.',
        isOn: true,
        temperature: 32,
        batteryLevel: null,
        powerConsumption: 110,
        basePower: 110,
        canHeat: false
      },
      {
        id: '203_aire_acondicionado',
        name: 'Aire Acondicionado Extractor',
        type: 'aire_acondicionado',
        description: 'Extractor y climatizador para disipar el calor generado por robots e impresoras 3D.',
        isOn: true,
        temperature: 20,
        batteryLevel: null,
        powerConsumption: 1450,
        basePower: 1450,
        canHeat: false
      },
      {
        id: '203_luces_taller',
        name: 'Iluminación Luz Fría',
        type: 'luces',
        description: 'Tubos LED ultra brillantes para trabajos de ensamblaje fino de microcontroladores.',
        isOn: true,
        temperature: 30,
        batteryLevel: null,
        powerConsumption: 180,
        basePower: 180,
        canHeat: false
      }
    ]
  }
];
