import React, { useState, useEffect, useRef } from 'react';

interface InteractiveEyeProps {
  size?: 'large' | 'small';
}

export const InteractiveEye: React.FC<InteractiveEyeProps> = ({ size = 'large' }) => {
  const [irisOffset, setIrisOffset] = useState({ x: 0, y: 0 });
  const [isBlinking, setIsBlinking] = useState(false);
  const eyeRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      if (!eyeRef.current) return;
      const rect = eyeRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const angle = Math.atan2(event.clientY - centerY, event.clientX - centerX);
      
      const maxDistance = size === 'large' ? 10 : 5;
      const x = Math.cos(angle) * maxDistance;
      const y = Math.sin(angle) * maxDistance;
      
      setIrisOffset({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [size]);

  const triggerBlink = () => {
    setIsBlinking(true);
    setTimeout(() => {
      setIsBlinking(false);
    }, 150);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.4) {
        triggerBlink();
      }
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const containerClasses = size === 'large'
    ? 'w-24 h-12 bg-white rounded-full relative overflow-hidden border-[4px] border-[#00cfff] shadow-[0_0_20px_rgba(0,207,255,0.4)] transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,207,255,0.8)] cursor-pointer'
    : 'w-16 h-8 bg-white rounded-full relative overflow-hidden border-[3px] border-[#00cfff] shadow-[0_0_15px_rgba(0,207,255,0.3)] transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,207,255,0.7)] cursor-pointer';

  const irisClasses = size === 'large'
    ? 'w-8 h-8 rounded-full bg-[radial-gradient(circle,_#7dd3fc,_#0284c7)] absolute top-1.5 left-7 flex items-center justify-center transition-all duration-100'
    : 'w-5 h-5 rounded-full bg-[radial-gradient(circle,_#7dd3fc,_#0284c7)] absolute top-1 left-5 flex items-center justify-center transition-all duration-100';

  const pupilClasses = size === 'large' ? 'w-4 h-4 rounded-full bg-black' : 'w-2.5 h-2.5 rounded-full bg-black';

  return (
    <div
      ref={eyeRef}
      className={containerClasses}
      onClick={triggerBlink}
    >
      {/* Eyelids */}
      <div
        className="absolute top-0 left-0 w-full bg-[#07111f] z-20 transition-all duration-150 origin-top border-b border-[#00cfff]/20"
        style={{ height: isBlinking ? '100%' : '0%' }}
      />
      <div
        className="absolute bottom-0 left-0 w-full bg-[#07111f] z-20 transition-all duration-150 origin-bottom border-t border-[#00cfff]/20"
        style={{ height: isBlinking ? '100%' : '0%' }}
      />

      {/* Iris & Pupil */}
      <div
        className={irisClasses}
        style={{
          transform: `translate(${irisOffset.x}px, ${irisOffset.y}px)`
        }}
      >
        <div className={pupilClasses} />
      </div>
    </div>
  );
};
