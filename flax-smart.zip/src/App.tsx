import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Laptop, 
  Tv, 
  Fan, 
  Lightbulb, 
  Thermometer, 
  Zap, 
  Volume2, 
  Plus, 
  Trash2, 
  LogOut, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  ChevronRight, 
  User, 
  RefreshCw, 
  Sliders, 
  AirVent,
  MonitorCheck,
  Power
} from 'lucide-react';
import { Classroom, Device, LogEntry, User as UserType } from './types';
import { INITIAL_CLASSROOMS } from './mockData';
import { InteractiveEye } from './components/InteractiveEye';

export default function App() {
  // STATE DEFINITIONS
  const [currentUser, setCurrentUser] = useState<UserType | null>(() => {
    const saved = localStorage.getItem('flax_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [classrooms, setClassrooms] = useState<Classroom[]>(() => {
    const saved = localStorage.getItem('flax_classrooms');
    return saved ? JSON.parse(saved) : INITIAL_CLASSROOMS;
  });

  const [selectedClassroomId, setSelectedClassroomId] = useState<string>(() => {
    return classrooms[0]?.id || 'aula_101';
  });

  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const saved = localStorage.getItem('flax_logs');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'log_1',
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        user: 'Sistema Flax',
        action: 'vinculó los dispositivos de las aulas con éxito',
        classroom: 'Todas las aulas',
        device: 'Controlador Central',
        type: 'success'
      }
    ];
  });

  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newDeviceName, setNewDeviceName] = useState('');
  const [newDeviceType, setNewDeviceType] = useState<Device['type']>('laptop');
  const [newDeviceDesc, setNewDeviceDesc] = useState('');
  const [newDeviceBatterySource, setNewDeviceBatterySource] = useState<'ac' | 'battery'>('ac');
  const [newDeviceBatteryLevel, setNewDeviceBatteryLevel] = useState(100);

  // SAVE STATE EFFECT
  useEffect(() => {
    localStorage.setItem('flax_classrooms', JSON.stringify(classrooms));
  }, [classrooms]);

  useEffect(() => {
    localStorage.setItem('flax_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('flax_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('flax_user');
    }
  }, [currentUser]);

  // LOG ADDER HELPER
  const addLogEntry = (
    user: string, 
    action: string, 
    classroom: string, 
    device: string, 
    type: LogEntry['type']
  ) => {
    const newLog: LogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      user,
      action,
      classroom,
      device,
      type
    };
    setLogs(prev => [newLog, ...prev].slice(0, 50));
  };

  // ACTIVE CLASSROOM COMPUTATION
  const activeClassroom = useMemo(() => {
    return classrooms.find(c => c.id === selectedClassroomId) || classrooms[0];
  }, [classrooms, selectedClassroomId]);

  // DERIVED STATS FOR CURRENT CLASSROOM
  const stats = useMemo(() => {
    if (!activeClassroom) return { activeCount: 0, totalPower: 0, avgTemp: 24, lowBatteryCount: 0 };
    const activeDevices = activeClassroom.devices.filter(d => d.isOn);
    const totalPower = activeClassroom.devices.reduce((acc, d) => acc + d.powerConsumption, 0);
    const avgTemp = activeClassroom.devices.length
      ? Math.round(activeClassroom.devices.reduce((acc, d) => acc + d.temperature, 0) / activeClassroom.devices.length)
      : 24;
    const lowBatteryCount = activeClassroom.devices.filter(
      d => d.batteryLevel !== null && d.batteryLevel <= 20
    ).length;

    return {
      activeCount: activeDevices.length,
      totalPower,
      avgTemp,
      lowBatteryCount
    };
  }, [activeClassroom]);

  // TOGGLE SINGLE DEVICE BY ID
  const toggleDevice = (deviceId: string) => {
    if (!currentUser) return;
    let deviceName = '';
    let actionState = false;
    let classroomName = '';

    setClassrooms(prev => prev.map(c => {
      const hasDevice = c.devices.some(d => d.id === deviceId);
      if (!hasDevice) return c;

      classroomName = c.name;
      const updatedDevices = c.devices.map(d => {
        if (d.id === deviceId) {
          deviceName = d.name;
          actionState = !d.isOn;
          const powerConsumption = actionState 
            ? d.basePower 
            : (d.type === 'aire_acondicionado' ? 1.2 : d.type === 'ventilador' ? 0.5 : 0.2);
          return { ...d, isOn: actionState, powerConsumption };
        }
        return d;
      });
      return { ...c, devices: updatedDevices };
    }));

    addLogEntry(
      currentUser.name,
      actionState ? 'encendió el dispositivo' : 'apagó el dispositivo',
      classroomName.split(' - ')[0],
      deviceName,
      actionState ? 'success' : 'warning'
    );
  };

  // BLOCK CONTROLS
  const handleMasterOff = () => {
    if (!currentUser || !activeClassroom) return;
    const activeDevicesCount = activeClassroom.devices.filter(d => d.isOn).length;
    if (activeDevicesCount === 0) return;

    setClassrooms(prev => prev.map(c => {
      if (c.id !== selectedClassroomId) return c;
      const updatedDevices = c.devices.map(d => {
        const standby = d.type === 'aire_acondicionado' ? 1.2 : d.type === 'ventilador' ? 0.5 : 0.2;
        return { ...d, isOn: false, powerConsumption: standby };
      });
      return { ...c, devices: updatedDevices };
    }));

    addLogEntry(
      currentUser.name,
      `presionó el Master Flax Switch y apagó ${activeDevicesCount} dispositivos en bloque`,
      activeClassroom.name.split(' - ')[0],
      'Flax Master Switch',
      'danger'
    );
  };

  const handleMasterOn = () => {
    if (!currentUser || !activeClassroom) return;

    setClassrooms(prev => prev.map(c => {
      if (c.id !== selectedClassroomId) return c;
      const updatedDevices = c.devices.map(d => {
        return { ...d, isOn: true, powerConsumption: d.basePower };
      });
      return { ...c, devices: updatedDevices };
    }));

    addLogEntry(
      currentUser.name,
      'encendió todos los dispositivos del aula para sincronización de clases',
      activeClassroom.name.split(' - ')[0],
      'Flax Master Switch',
      'success'
    );
  };

  // SESSION LOGIN / LOGOUT
  const handleLogin = () => {
    const guestUser: UserType = {
      username: 'invitado_flax',
      name: 'Invitado Flax',
      role: 'Invitado',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150',
      email: 'invitado@colegioflax.edu.pe'
    };
    setCurrentUser(guestUser);
    addLogEntry(guestUser.name, 'inició sesión en el centro de control', 'Dashboard', 'Ingreso Directo', 'info');
  };

  const handleLogout = () => {
    if (currentUser) {
      addLogEntry(currentUser.name, 'cerró sesión', 'Dashboard', 'Cierre manual', 'info');
    }
    setCurrentUser(null);
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  // ADD DEVICE HANDLER
  const handleAddDevice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !activeClassroom) return;

    const name = newDeviceName.trim() || `Dispositivo ${newDeviceType}`;
    const desc = newDeviceDesc.trim() || `Equipo de tipo ${newDeviceType} administrado en tiempo real por Flax.`;
    const batteryVal = newDeviceBatterySource === 'battery' ? newDeviceBatteryLevel : null;

    const basePowerValues: Record<Device['type'], number> = {
      laptop: 65,
      proyector: 280,
      ventilador: 75,
      luces: 150,
      aire_acondicionado: 1500,
      smartboard: 400,
      bocinas: 120
    };

    const newDevice: Device = {
      id: `dev_${Date.now()}`,
      name,
      type: newDeviceType,
      description: desc,
      isOn: false,
      temperature: 24,
      batteryLevel: batteryVal,
      powerConsumption: 0.2,
      basePower: basePowerValues[newDeviceType] || 100,
      canHeat: ['laptop', 'proyector', 'smartboard'].includes(newDeviceType)
    };

    setClassrooms(prev => prev.map(c => {
      if (c.id !== selectedClassroomId) return c;
      return { ...c, devices: [...c.devices, newDevice] };
    }));

    addLogEntry(
      currentUser.name,
      `agregó y vinculó un nuevo dispositivo: ${newDevice.name}`,
      activeClassroom.name.split(' - ')[0],
      newDevice.name,
      'success'
    );

    // Reset Form & Close
    setNewDeviceName('');
    setNewDeviceDesc('');
    setNewDeviceBatterySource('ac');
    setNewDeviceBatteryLevel(100);
    setIsAddModalOpen(false);
  };

  // TELEMETRY SIMULATION LOOP
  useEffect(() => {
    const interval = setInterval(() => {
      setClassrooms(prev => prev.map(classroom => {
        let classroomChanged = false;

        const updatedDevices = classroom.devices.map(device => {
          let temp = device.temperature;
          let battery = device.batteryLevel;
          let power = device.powerConsumption;
          let changed = false;

          // 1. Temperature fluctuates
          if (device.isOn && device.canHeat) {
            const maxTemp = device.type === 'proyector' ? 62 : 45;
            if (temp < maxTemp) {
              temp = Math.min(maxTemp, temp + (Math.random() > 0.65 ? 1 : 0));
              changed = true;
            }
          } else {
            const ambient = 23;
            if (temp > ambient) {
              temp = Math.max(ambient, temp - (Math.random() > 0.65 ? 1 : 0));
              changed = true;
            }
          }

          // 2. Battery drainage
          if (battery !== null) {
            if (device.isOn && battery > 0) {
              if (Math.random() > 0.88) {
                battery = Math.max(0, battery - 1);
                changed = true;
              }
            } else if (!device.isOn && battery < 100) {
              if (Math.random() > 0.75) {
                battery = Math.min(100, battery + 1);
                changed = true;
              }
            }
          }

          // 3. Power fluctuation
          if (device.isOn) {
            const variance = (Math.random() - 0.5) * (device.basePower * 0.05);
            const newPower = Math.round(device.basePower + variance);
            if (Math.abs(power - newPower) > 2) {
              power = newPower;
              changed = true;
            }
          }

          if (changed) {
            classroomChanged = true;
            return { ...device, temperature: temp, batteryLevel: battery, powerConsumption: power };
          }
          return device;
        });

        return classroomChanged ? { ...classroom, devices: updatedDevices } : classroom;
      }));
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  // UTILS FOR ICON SELECTION
  const getDeviceIcon = (type: Device['type'], isOn: boolean) => {
    const size = 26;
    const colorClass = isOn 
      ? "text-[#00cfff] drop-shadow-[0_0_8px_rgba(0,207,255,0.7)]" 
      : "text-gray-500";

    switch (type) {
      case 'laptop':
        return <Laptop size={size} className={colorClass} />;
      case 'proyector':
        return <Tv size={size} className={colorClass} />;
      case 'ventilador':
        return <Fan size={size} className={`${colorClass} ${isOn ? 'animate-spin [animation-duration:2s] text-[#00ff88]' : ''}`} />;
      case 'luces':
        return <Lightbulb size={size} className={isOn ? "text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.7)]" : "text-gray-500"} />;
      case 'aire_acondicionado':
        return <AirVent size={size} className={colorClass} />;
      case 'smartboard':
        return <MonitorCheck size={size} className={colorClass} />;
      case 'bocinas':
        return <Volume2 size={size} className={colorClass} />;
      default:
        return <Sliders size={size} className={colorClass} />;
    }
  };

  // HOURLY HISTORIC ENERGY DATA COMPUTATION
  const energyChartData = useMemo(() => {
    const currentKW = Number((stats.totalPower / 1000).toFixed(2));
    return [
      { hour: '09:00', value: 1.15, label: '09:00 AM' },
      { hour: '10:00', value: 1.45, label: '10:00 AM' },
      { hour: '11:00', value: 1.85, label: '11:00 AM' },
      { hour: '12:00', value: 1.20, label: '12:00 PM (Recreo)' },
      { hour: '13:00', value: 1.60, label: '01:00 PM' },
      { hour: '14:00', value: 0.95, label: '02:00 PM' },
      { hour: 'Ahora', value: currentKW, label: 'Ahora (En Vivo)', isCurrent: true }
    ];
  }, [stats.totalPower]);

  const maxChartVal = useMemo(() => {
    return Math.max(...energyChartData.map(d => d.value), 2.5);
  }, [energyChartData]);

  // EFFICIENCY COMPUTATION
  const savedPowerPercent = useMemo(() => {
    return Math.round(35 - (stats.totalPower / 2500) * 15);
  }, [stats.totalPower]);

  return (
    <div className="relative min-h-screen text-white bg-[#07111f] font-sans overflow-x-hidden selection:bg-[#00cfff]/30 selection:text-white">
      {/* Background radial blurs */}
      <div className="absolute top-0 right-0 w-[45vw] h-[45vw] bg-[#00cfff]/5 rounded-full blur-[140px] pointer-events-none z-0"></div>
      <div className="absolute bottom-10 left-10 w-[35vw] h-[35vw] bg-[#0284c7]/5 rounded-full blur-[120px] pointer-events-none z-0"></div>

      <AnimatePresence mode="wait">
        {!currentUser ? (
          /* LOGIN SCREEN */
          <motion.div
            key="login"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.3 }}
            className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4"
          >
            <div className="w-full max-w-md">
              {/* Logo Header */}
              <div className="flex flex-col items-center mb-8 text-center">
                <InteractiveEye size="large" />
                <h1 className="text-4xl font-extrabold text-[#00cfff] tracking-tight mt-4">Flax</h1>
                <p className="text-[#7dd3fc] text-xs mt-1 font-mono uppercase tracking-widest">Smart Classroom Hub</p>
                <p className="text-gray-400 text-sm mt-3 max-w-xs">
                  Inicia sesión para controlar y monitorear los dispositivos conectados de tus aulas.
                </p>
              </div>

              {/* Guest Login Card */}
              <div className="bg-[#0f172a] rounded-3xl p-8 border border-white/10 shadow-[0_15px_40px_rgba(0,0,0,0.5)] relative overflow-hidden backdrop-blur-md">
                <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#00cfff] to-[#0284c7]"></div>

                <h2 className="flex items-center gap-2 text-xl font-bold text-white mb-4">
                  <User size={20} className="text-[#00cfff]" />
                  Acceso de Invitado
                </h2>

                <p className="text-gray-400 text-xs leading-relaxed mb-6">
                  Ingresa al centro de control como invitado de Flax. Tendrás acceso completo al monitoreo de energía y control de dispositivos inteligentes.
                </p>

                <div className="space-y-4 mb-6">
                  <div className="flex items-start gap-2.5 text-xs text-gray-300">
                    <CheckCircle2 size={16} className="text-[#00cfff] shrink-0 mt-0.5" />
                    <span>Acceso instantáneo sin credenciales</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-gray-300">
                    <CheckCircle2 size={16} className="text-[#00cfff] shrink-0 mt-0.5" />
                    <span>Control en tiempo real de equipos IoT</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-gray-300">
                    <CheckCircle2 size={16} className="text-[#00cfff] shrink-0 mt-0.5" />
                    <span>Sincronización mediante Flax Mesh Network</span>
                  </div>
                </div>

                <button
                  onClick={handleLogin}
                  className="w-full bg-[#00cfff] text-[#07111f] font-bold py-4 px-6 rounded-2xl transition-all duration-300 hover:bg-[#00b0d9] active:scale-[0.98] flex items-center justify-center gap-2.5 shadow-[0_4px_15px_rgba(0,207,255,0.3)] cursor-pointer text-sm"
                >
                  <span>Ingresar como Invitado</span>
                  <ChevronRight size={18} strokeWidth={2.5} />
                </button>
              </div>

              <div className="text-center mt-6">
                <p className="text-gray-500 text-xs">
                  © 2026 Flax Technologies • Sistema de Gestión de Energía Inteligente
                </p>
              </div>
            </div>
          </motion.div>
        ) : (
          /* APP DASHBOARD */
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="relative z-10 flex flex-col min-h-screen"
          >
            {/* STICKY NAVBAR */}
            <nav className="sticky top-0 z-40 bg-[#07111f]/80 backdrop-blur-md border-b border-white/5 py-4 px-6 md:px-12 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <InteractiveEye size="small" />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-lg font-black tracking-wider text-[#00cfff]">FLAX</span>
                    <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Mesh</span>
                  </div>
                  <span className="text-[9px] font-mono uppercase tracking-widest text-gray-400 block mt-0.5">Control Central v3.1</span>
                </div>
              </div>

              {/* User details & logout */}
              <div className="flex items-center gap-3">
                <div className="hidden md:block text-right">
                  <span className="block text-xs font-bold text-white">{currentUser.name}</span>
                  <span className="block text-[10px] text-gray-400 font-mono mt-0.5">{currentUser.role}</span>
                </div>
                <img 
                  src={currentUser.avatar} 
                  alt="Avatar" 
                  className="w-9 h-9 rounded-full border border-white/10"
                />
                <button
                  onClick={handleLogout}
                  className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-gray-400 hover:text-white hover:bg-white/10 hover:border-white/10 active:scale-95 transition-all cursor-pointer"
                  title="Cerrar Sesión"
                >
                  <LogOut size={16} />
                </button>
              </div>
            </nav>

            {/* DASHBOARD BODY */}
            <main className="flex-grow p-6 md:p-12 space-y-8 max-w-7xl mx-auto w-full">
              
              {/* WELCOME BANNER & MASTER CONTROLS */}
              <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-[#0f172a]/60 border border-white/5 rounded-3xl p-6 backdrop-blur-md">
                <div>
                  <h2 className="text-2xl font-black text-white tracking-tight">
                    Bienvenido, {currentUser.name.split(' ')[0]}
                  </h2>
                  <p className="text-xs text-gray-400 mt-1 max-w-lg leading-relaxed">
                    Sincronización en tiempo real. Utiliza el Flax Master Switch para apagar o encender el bloque completo de dispositivos del aula seleccionada.
                  </p>
                </div>

                {/* Master block controls */}
                <div className="flex items-center gap-3 w-full lg:w-auto">
                  <div className="flex items-center gap-2 bg-[#07111f] border border-white/5 py-2.5 px-4 rounded-xl w-full lg:w-auto justify-between lg:justify-start">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full transition-all duration-300 ${stats.activeCount > 0 ? 'bg-amber-400 shadow-[0_0_8px_#fbbf24]' : 'bg-gray-600'}`}></div>
                      <span className="text-[10px] font-mono tracking-wider text-gray-400 uppercase">Master Switch</span>
                    </div>

                    <div className="flex items-center gap-1.5 ml-4">
                      <button
                        onClick={handleMasterOff}
                        disabled={stats.activeCount === 0}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold font-mono uppercase tracking-wider transition-all duration-300 flex items-center gap-1 cursor-pointer ${
                          stats.activeCount > 0 
                            ? 'bg-red-500 hover:bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.4)]'
                            : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                        }`}
                      >
                        <Power size={11} />
                        <span>Off</span>
                      </button>

                      <button
                        onClick={handleMasterOn}
                        className="px-3 py-1.5 rounded-lg text-[10px] font-bold font-mono uppercase tracking-wider bg-emerald-500 hover:bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)] transition-all duration-300 flex items-center gap-1 cursor-pointer"
                      >
                        <Power size={11} />
                        <span>On</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* BATTERY ALERT BAR */}
              {stats.lowBatteryCount > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-500/10 border border-red-500/20 text-red-400 px-6 py-4 rounded-3xl flex items-start gap-3.5"
                >
                  <AlertTriangle className="shrink-0 mt-0.5 animate-pulse text-red-400" size={18} />
                  <span className="text-xs leading-relaxed">
                    Hay <strong>{stats.lowBatteryCount}</strong> dispositivo{stats.lowBatteryCount > 1 ? 's' : ''} con batería baja (≤20%) en {activeClassroom.name.split(' - ')[0]}.
                  </span>
                </motion.div>
              )}

              {/* CLASSROOM SELECTOR RAIL */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 font-mono">Selección de Aula</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="classroom-tabs">
                  {classrooms.map((room) => {
                    const isActive = room.id === selectedClassroomId;
                    const activeCount = room.devices.filter(d => d.isOn).length;

                    return (
                      <button
                        key={room.id}
                        onClick={() => setSelectedClassroomId(room.id)}
                        className={`px-5 py-3 rounded-2xl font-semibold text-sm transition-all text-left flex items-center gap-3 cursor-pointer border ${
                          isActive
                            ? 'bg-[#00cfff] text-[#07111f] border-[#00cfff] shadow-[0_5px_20px_rgba(0,207,255,0.25)]'
                            : 'bg-[#07111f] hover:bg-[#07111f]/80 text-gray-300 hover:text-white border-white/5'
                        }`}
                      >
                        <Zap size={16} className={isActive ? 'text-[#07111f]' : 'text-[#00cfff]'} strokeWidth={2.5} />
                        <div>
                          <span className="block leading-tight">{room.name.split(' - ')[0]}</span>
                          <span className={`text-[9px] font-mono ${isActive ? 'text-[#07111f]/80' : 'text-gray-500'} block mt-0.5`}>
                            {activeCount} activo{activeCount !== 1 ? 's' : ''}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* THREE-COLUMN BENTO GRID: STATS, GRID, CHART & LOGS */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* COLUMN 1: CONTROLS & DEVICES GRID (lg:col-span-8) */}
                <div className="lg:col-span-8 space-y-6">
                  
                  {/* Grid header & add btn */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-black text-white tracking-tight" id="devices-grid-title">
                        Dispositivos en {activeClassroom.name.split(' - ')[1]}
                      </h3>
                      <p className="text-[11px] text-gray-400 font-mono mt-0.5 uppercase tracking-wider">{activeClassroom.building}</p>
                    </div>

                    <button
                      onClick={() => setIsAddModalOpen(true)}
                      className="bg-white/5 border border-white/5 text-xs text-gray-300 font-bold px-4 py-2.5 rounded-xl hover:text-white hover:bg-white/10 hover:border-[#00cfff]/30 transition-all active:scale-[0.98] flex items-center gap-2 cursor-pointer shadow-sm"
                    >
                      <Plus size={14} />
                      <span>Vincular Dispositivo</span>
                    </button>
                  </div>

                  {/* Devices responsive grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="devices-grid">
                    {activeClassroom.devices.length === 0 ? (
                      <div className="col-span-1 md:col-span-2 text-center py-12 bg-[#0f172a] rounded-3xl border border-white/5 text-gray-500 text-sm">
                        No hay dispositivos vinculados a esta aula aún.
                        <p className="text-xs text-gray-600 mt-1">Vincula uno presionando "Vincular Dispositivo" arriba.</p>
                      </div>
                    ) : (
                      activeClassroom.devices.map((device) => {
                        const isLowBattery = device.batteryLevel !== null && device.batteryLevel <= 20;
                        const tempClass = device.temperature >= 50 
                          ? 'text-red-400 font-bold' 
                          : (device.temperature >= 35 ? 'text-amber-400 font-semibold' : 'text-emerald-400');

                        return (
                          <div
                            key={device.id}
                            className={`bg-[#0f172a] rounded-3xl p-5 border border-white/10 hover:border-[#00cfff] transition-all duration-300 relative overflow-hidden flex flex-col justify-between h-[255px] shadow-[0_4px_20px_rgba(0,0,0,0.2)] ${
                              device.isOn ? 'shadow-[0_0_20px_rgba(0,207,255,0.15)] ring-1 ring-[#00cfff]/20' : ''
                            }`}
                          >
                            {/* Glow spot */}
                            {device.isOn && (
                              <div className="absolute top-[-20%] left-[-20%] w-[60%] h-[60%] bg-[#00cfff]/5 rounded-full blur-[40px] pointer-events-none"></div>
                            )}

                            <div>
                              {/* Device top card details */}
                              <div className="flex items-start justify-between relative z-10">
                                <div className={`p-3 rounded-2xl ${device.isOn ? 'bg-[#00cfff]/10' : 'bg-[#07111f]/80'} border border-white/5`}>
                                  {getDeviceIcon(device.type, device.isOn)}
                                </div>

                                <div className="flex items-center gap-1.5">
                                  <span className={`text-[10px] font-mono uppercase tracking-wider ${device.isOn ? 'text-[#00ff88]' : 'text-gray-500'}`}>
                                    {device.isOn ? 'Encendido' : 'Apagado'}
                                  </span>
                                  <div className={`w-2 h-2 rounded-full transition-all duration-300 ${
                                    device.isOn ? 'bg-[#00ff88] shadow-[0_0_10px_#00ff88]' : 'bg-gray-700'
                                  }`}></div>
                                </div>
                              </div>

                              {/* Title / Description */}
                              <div className="mt-3.5 relative z-10">
                                <h4 className="text-sm font-bold text-white tracking-tight leading-tight">{device.name}</h4>
                                <p className="text-xs text-gray-400 mt-1 line-clamp-2 min-h-[32px] leading-relaxed">{device.description}</p>
                              </div>
                            </div>

                            {/* Telemetry stats metrics */}
                            <div className="grid grid-cols-2 gap-2 my-2 pt-2 border-t border-white/5 relative z-10">
                              <div className="flex items-center gap-1.5">
                                <Thermometer size={14} className="text-gray-500" />
                                <div className="text-[11px] font-mono">
                                  <span className="text-gray-500 block text-[9px] uppercase leading-none mb-0.5">Temp</span>
                                  <span className={tempClass}>{device.temperature}°C</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <Zap size={14} className="text-gray-500" />
                                <div className="text-[11px] font-mono">
                                  <span className="text-gray-500 block text-[9px] uppercase leading-none mb-0.5">Consumo</span>
                                  <span className={device.isOn ? 'text-[#00cfff] font-bold' : 'text-gray-400'}>{device.powerConsumption}W</span>
                                </div>
                              </div>
                            </div>

                            {/* Bottom connection type & Switch */}
                            <div className="flex items-center justify-between pt-2 border-t border-white/5 relative z-10">
                              {device.batteryLevel === null ? (
                                <div className="flex items-center gap-1.5 text-gray-400 font-mono text-[11px] bg-white/5 border border-white/5 px-2 py-0.5 rounded-lg">
                                  <Zap size={10} className="text-gray-500" />
                                  <span>Red AC</span>
                                </div>
                              ) : (
                                <div className={`flex items-center gap-1.5 font-mono text-[11px] px-2 py-0.5 rounded-lg border ${
                                  isLowBattery
                                    ? 'text-red-400 bg-red-500/10 border-red-500/20 animate-pulse'
                                    : 'text-[#00cfff] bg-[#00cfff]/10 border-[#00cfff]/20'
                                }`}>
                                  <Sliders size={10} className={isLowBattery ? 'text-red-400' : 'text-[#00cfff]'} />
                                  <span>{device.batteryLevel}%</span>
                                </div>
                              )}

                              <button
                                onClick={() => toggleDevice(device.id)}
                                className={`relative w-12 h-6.5 rounded-full transition-all duration-300 flex items-center p-0.5 cursor-pointer ${
                                  device.isOn ? 'bg-[#00cfff] shadow-[0_0_10px_rgba(0,207,255,0.4)]' : 'bg-gray-800'
                                }`}
                              >
                                <div className={`w-4.5 h-4.5 rounded-full shadow-[0_2px_4px_rgba(0,0,0,0.4)] transition-all duration-200 ${
                                  device.isOn ? 'bg-[#07111f] translate-x-[24px]' : 'bg-gray-400 translate-x-0'
                                }`}></div>
                              </button>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* COLUMN 2: SUMMARY METRICS, LIVE CHART & ACTIVITY LOGS (lg:col-span-4) */}
                <div className="lg:col-span-4 space-y-6">
                  
                  {/* METRICS PANEL */}
                  <div className="bg-[#0f172a] rounded-3xl p-6 border border-white/10 space-y-5 shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#00cfff] to-emerald-500"></div>

                    <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 font-mono">Métricas de Aula</h3>

                    <div className="grid grid-cols-3 gap-4">
                      {/* Active count */}
                      <div className="text-center py-2 bg-[#07111f]/60 rounded-2xl border border-white/5">
                        <span className="block text-[10px] uppercase font-mono tracking-wider text-gray-500">Equipos</span>
                        <div className="flex items-baseline justify-center gap-1 mt-1">
                          <span className="text-xl font-black text-white">{stats.activeCount}</span>
                          <span className="text-[10px] text-gray-500 font-mono">/ {activeClassroom?.devices.length || 0}</span>
                        </div>
                      </div>

                      {/* Total power */}
                      <div className="text-center py-2 bg-[#07111f]/60 rounded-2xl border border-white/5">
                        <span className="block text-[10px] uppercase font-mono tracking-wider text-gray-500">Carga</span>
                        <div className="flex items-baseline justify-center gap-0.5 mt-1">
                          <span className="text-xl font-black text-[#00cfff]">
                            {stats.totalPower >= 1000 ? (stats.totalPower / 1000).toFixed(2) : Math.round(stats.totalPower)}
                          </span>
                          <span className="text-[10px] text-gray-500 font-mono">
                            {stats.totalPower >= 1000 ? 'kW' : 'W'}
                          </span>
                        </div>
                      </div>

                      {/* Avg Temp */}
                      <div className="text-center py-2 bg-[#07111f]/60 rounded-2xl border border-white/5">
                        <span className="block text-[10px] uppercase font-mono tracking-wider text-gray-500">Temp Med</span>
                        <div className="flex items-baseline justify-center gap-0.5 mt-1">
                          <span className="text-xl font-black text-white">{stats.avgTemp}</span>
                          <span className="text-[10px] text-gray-500 font-mono">°C</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* ENERGY CONSUMPTION HISTORIC CHART */}
                  <div className="bg-[#0f172a] rounded-3xl p-6 border border-white/10 space-y-4 shadow-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-sm font-bold text-white tracking-tight">Monitoreo de Energía</h3>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5 uppercase tracking-wider">Historial por horas</p>
                      </div>

                      <div className="text-right">
                        <span className="text-lg font-black text-[#00cfff] tracking-tight block">
                          {(stats.totalPower / 1000).toFixed(2)} kW
                        </span>
                        <span className="text-[9px] font-semibold text-emerald-400 flex items-center gap-1 justify-end font-mono">
                          <Zap size={10} />
                          +{savedPowerPercent}% ahorro
                        </span>
                      </div>
                    </div>

                    {/* Chart Container (Custom SVG/CSS Bars) */}
                    <div className="h-[150px] relative mt-4 flex items-end gap-3.5 px-1.5 pb-2 border-b border-white/5">
                      {/* Grid background lines */}
                      <div className="absolute top-0 left-0 w-full h-full flex flex-col justify-between pointer-events-none opacity-5 z-0">
                        <div className="border-b border-white w-full h-0"></div>
                        <div className="border-b border-white w-full h-0"></div>
                        <div className="border-b border-white w-full h-0"></div>
                        <div className="border-b border-white w-full h-0"></div>
                      </div>

                      {/* Bar columns */}
                      {energyChartData.map((d) => {
                        const heightPercent = (d.value / maxChartVal) * 100;
                        const barColor = d.isCurrent
                          ? 'bg-gradient-to-t from-[#00cfff] to-[#7dd3fc] shadow-[0_0_15px_rgba(0,207,255,0.4)]'
                          : 'bg-[#0284c7]/40 hover:bg-[#00cfff]/70';

                        return (
                          <div 
                            key={d.hour} 
                            className="flex-1 flex flex-col items-center group relative cursor-pointer z-10 h-full justify-end"
                          >
                            {/* Custom interactive tooltip */}
                            <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-[#07111f] border border-[#00cfff]/30 px-2.5 py-1.5 rounded-xl text-center shadow-lg pointer-events-none transition-all duration-200 opacity-0 scale-90 group-hover:opacity-100 group-hover:scale-100 group-hover:translate-y-0 translate-y-2 z-20 w-28">
                              <p className="text-[10px] text-[#7dd3fc] font-semibold leading-none">{d.label}</p>
                              <p className="text-xs text-white font-mono font-bold mt-1">{d.value.toFixed(2)} kW</p>
                            </div>

                            {/* Column pillar wrapper */}
                            <div className="w-full bg-[#07111f]/90 rounded-t-xl h-[100px] flex items-end overflow-hidden border border-white/5 relative">
                              <div
                                style={{ height: `${heightPercent}%` }}
                                className={`w-full rounded-t-lg transition-all duration-500 ${barColor}`}
                              ></div>
                            </div>

                            {/* Label */}
                            <span className={`text-[9px] font-mono mt-2 transition-colors duration-200 group-hover:text-white ${
                              d.isCurrent ? 'text-[#00cfff] font-bold' : 'text-gray-500'
                            }`}>
                              {d.hour}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* REAL-TIME TERMINAL LOGS */}
                  <div className="bg-[#0f172a] rounded-3xl p-6 border border-white/10 space-y-4 shadow-lg flex flex-col h-[320px]">
                    <div className="flex justify-between items-center shrink-0">
                      <div>
                        <h3 className="text-sm font-bold text-white tracking-tight">Bitácora de Eventos</h3>
                        <p className="text-[10px] text-gray-500 font-mono mt-0.5 uppercase tracking-wider">Flax Mesh Network</p>
                      </div>

                      <button
                        onClick={handleClearLogs}
                        disabled={logs.length === 0}
                        className={`text-[10px] font-bold font-mono tracking-wider transition-all px-3 py-1.5 rounded-lg border ${
                          logs.length > 0 
                            ? 'text-gray-400 hover:text-white hover:bg-white/5 border-white/5 hover:border-white/10 cursor-pointer'
                            : 'text-gray-600 border-transparent cursor-not-allowed'
                        }`}
                      >
                        Limpiar
                      </button>
                    </div>

                    {/* Logs list box scrollable */}
                    <div className="flex-grow overflow-y-auto space-y-3.5 pr-1" id="logs-container">
                      {logs.length === 0 ? (
                        <div className="text-center py-12 text-gray-500 text-sm h-full flex flex-col justify-center items-center">
                          No hay actividades registradas.
                          <p className="text-xs text-gray-600 mt-1">Prueba encendiendo o apagando dispositivos.</p>
                        </div>
                      ) : (
                        logs.map((log) => {
                          let typeClass = 'border-l-2 border-l-[#00cfff]/70 bg-[#00cfff]/5';
                          switch (log.type) {
                            case 'success':
                              typeClass = 'border-l-2 border-l-[#00ff88]/70 bg-[#00ff88]/5';
                              break;
                            case 'warning':
                              typeClass = 'border-l-2 border-l-amber-500/70 bg-amber-500/5';
                              break;
                            case 'danger':
                              typeClass = 'border-l-2 border-l-red-500/70 bg-red-500/5';
                              break;
                            case 'info':
                            default:
                              typeClass = 'border-l-2 border-l-[#00cfff]/70 bg-[#00cfff]/5';
                              break;
                          }

                          return (
                            <div
                              key={log.id}
                              className={`p-3 rounded-2xl border border-white/5 flex items-start gap-3 text-xs transition-all duration-200 hover:border-white/10 ${typeClass}`}
                            >
                              <div className="flex-grow space-y-1">
                                <div className="text-white">
                                  <span className="font-semibold text-[#7dd3fc]">{log.user}</span> {log.action}
                                </div>
                                <div className="flex items-center justify-between text-[10px] text-gray-500 font-mono">
                                  <span>{log.device} • {log.classroom}</span>
                                  <span>{log.timestamp}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                </div>
              </div>

            </main>
          </motion.div>
        )}
      </AnimatePresence>

      {/* VINCULATE NEW DEVICE MODAL */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Backdrop blur overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              id="modal-backdrop"
            ></motion.div>

            {/* Modal panel card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ type: 'spring', duration: 0.4 }}
              className="bg-[#0f172a] border border-white/10 rounded-3xl p-6 w-full max-w-md shadow-2xl relative overflow-hidden z-10"
              id="modal-body"
            >
              <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#00cfff] to-[#0284c7]"></div>

              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-lg font-black text-white tracking-tight">Vincular Dispositivo</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Agrega un nuevo nodo IoT a la red mesh.</p>
                </div>

                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-1.5 rounded-lg bg-white/5 border border-white/5 text-gray-400 hover:text-white hover:bg-white/10 cursor-pointer"
                  id="close-modal-btn"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Add form */}
              <form onSubmit={handleAddDevice} className="space-y-4" id="add-device-form">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono mb-2">Nombre del Equipo</label>
                  <input
                    type="text"
                    required
                    value={newDeviceName}
                    onChange={(e) => setNewDeviceName(e.target.value)}
                    placeholder="ej. Laptop Estudiante 3, Proyector EPSON B"
                    className="w-full bg-[#07111f] border border-white/10 rounded-xl py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00cfff] text-xs font-semibold"
                    id="new-device-name"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono mb-2">Tipo de Dispositivo</label>
                    <select
                      value={newDeviceType}
                      onChange={(e) => setNewDeviceType(e.target.value as Device['type'])}
                      className="w-full bg-[#07111f] border border-white/10 rounded-xl py-2.5 px-4 text-white focus:outline-none focus:border-[#00cfff] text-xs font-semibold cursor-pointer"
                      id="new-device-type"
                    >
                      <option value="laptop">Laptop</option>
                      <option value="proyector">Proyector / Tv</option>
                      <option value="ventilador">Ventilador</option>
                      <option value="luces">Iluminación LED</option>
                      <option value="aire_acondicionado">Aire Acondicionado</option>
                      <option value="smartboard">Smartboard</option>
                      <option value="bocinas">Sistema Sonido</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono mb-2">Alimentación</label>
                    <div className="flex bg-[#07111f] border border-white/10 rounded-xl p-1 h-[38px]">
                      <button
                        type="button"
                        onClick={() => setNewDeviceBatterySource('ac')}
                        className={`flex-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                          newDeviceBatterySource === 'ac' 
                            ? 'bg-[#00cfff] text-[#07111f]' 
                            : 'text-gray-400'
                        }`}
                        id="power-source-ac"
                      >
                        Red AC
                      </button>

                      <button
                        type="button"
                        onClick={() => setNewDeviceBatterySource('battery')}
                        className={`flex-1 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                          newDeviceBatterySource === 'battery' 
                            ? 'bg-[#00cfff] text-[#07111f]' 
                            : 'text-gray-400'
                        }`}
                        id="power-source-battery"
                      >
                        Batería
                      </button>
                    </div>
                  </div>
                </div>

                {newDeviceBatterySource === 'battery' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-2 border-t border-white/5 pt-3"
                    id="battery-level-container"
                  >
                    <div className="flex justify-between items-center">
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono">Nivel de Carga Inicial</label>
                      <span className="text-xs font-mono font-bold text-[#00cfff]" id="battery-level-label">
                        {newDeviceBatteryLevel}%
                      </span>
                    </div>

                    <input
                      type="range"
                      min="5"
                      max="100"
                      value={newDeviceBatteryLevel}
                      onChange={(e) => setNewDeviceBatteryLevel(Number(e.target.value))}
                      className="w-full accent-[#00cfff] cursor-pointer"
                      id="new-device-battery-level"
                    />
                  </motion.div>
                )}

                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono mb-2">Descripción (Opcional)</label>
                  <textarea
                    value={newDeviceDesc}
                    onChange={(e) => setNewDeviceDesc(e.target.value)}
                    placeholder="Descripción técnica del dispositivo..."
                    rows={2}
                    className="w-full bg-[#07111f] border border-white/10 rounded-xl py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00cfff] text-xs font-semibold resize-none"
                    id="new-device-desc"
                  ></textarea>
                </div>

                <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white text-xs font-bold py-3 px-4 rounded-xl transition-all cursor-pointer border border-white/5"
                    id="cancel-modal-btn"
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    className="flex-1 bg-[#00cfff] hover:bg-[#00b0d9] text-[#07111f] text-xs font-black py-3 px-4 rounded-xl shadow-[0_4px_15px_rgba(0,207,255,0.3)] transition-all cursor-pointer"
                  >
                    Vincular Nodo
                  </button>
                </div>
              </form>
            </motion.div>

          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
